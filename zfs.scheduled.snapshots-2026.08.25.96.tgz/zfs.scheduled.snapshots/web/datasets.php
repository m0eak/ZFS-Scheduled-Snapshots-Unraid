<?php
$nextCurrentPage = 'datasets';
require __DIR__ . '/i18n.php';
$nextPageTitle = zss_t('datasets.title');
$nextPageDescription = zss_t('datasets.create.description');
$nextPageScript = 'assets/js/datasets.js';
require __DIR__ . '/layout/shell.php';
?>

<div class="zss-page-actions" data-zss-entrance="0">
    <a class="zss-btn zss-btn-primary" href="<?php echo htmlspecialchars(withLang('snapshots.php')); ?>"><?php echo htmlspecialchars(zss_t('datasets.actions.snapshots')); ?></a>
</div>

<section class="zss-context-strip" data-zss-entrance="1" aria-label="<?php echo htmlspecialchars(zss_t('overview.dataset_status')); ?>">
    <div class="zss-context-stat"><span><?php echo htmlspecialchars(zss_t('overview.stats.dataset_count')); ?></span><strong id="ctx-dataset-count">-</strong></div>
    <div class="zss-context-stat"><span><?php echo htmlspecialchars(zss_t('overview.stats.enabled_count')); ?></span><strong id="ctx-enabled-count">-</strong></div>
    <div class="zss-context-stat"><span><?php echo htmlspecialchars(zss_t('overview.stats.snapshot_count')); ?></span><strong id="ctx-snapshot-count">-</strong></div>
</section>

<section class="zss-panel" data-zss-entrance="2">
    <div class="zss-panel-header"><h2><?php echo htmlspecialchars(zss_t('datasets.title')); ?></h2><p><?php echo htmlspecialchars(zss_t('datasets.create.description')); ?></p></div>
    <div class="zss-table-wrap"><table class="zss-table"><thead><tr><th><?php echo htmlspecialchars(zss_t('table.dataset')); ?></th><th><?php echo htmlspecialchars(zss_t('table.status')); ?></th><th><?php echo htmlspecialchars(zss_t('table.frequency')); ?></th><th><?php echo htmlspecialchars(zss_t('table.keep')); ?></th><th><?php echo htmlspecialchars(zss_t('table.keep_days')); ?></th><th><?php echo htmlspecialchars(zss_t('table.readonly')); ?></th><th><?php echo htmlspecialchars(zss_t('table.held')); ?></th><th><?php echo htmlspecialchars(zss_t('table.snapshot_count')); ?></th><th><?php echo htmlspecialchars(zss_t('table.last_snapshot')); ?></th><th><?php echo htmlspecialchars(zss_t('table.actions')); ?></th></tr></thead><tbody id="datasets-table"><tr><td colspan="10" class="zss-table-message"><?php echo htmlspecialchars(zss_t('common.loading')); ?></td></tr></tbody></table></div>
</section>

<section class="zss-panel" data-zss-entrance="3">
    <div class="zss-panel-header">
        <h2><?php echo htmlspecialchars(zss_t('datasets.create.title')); ?></h2>
        <p><?php echo htmlspecialchars(zss_t('datasets.create.description')); ?></p>
    </div>
    <div class="zss-form-grid zss-panel-body">
        <label class="zss-field"><span><?php echo htmlspecialchars(zss_t('datasets.create.parent')); ?></span><select id="new-dataset-parent" class="zss-select"></select></label>
        <label class="zss-field"><span><?php echo htmlspecialchars(zss_t('datasets.create.child')); ?></span><input id="new-dataset-child" class="zss-input" type="text" placeholder="appdata/media"></label>
        <label class="zss-field"><span><?php echo htmlspecialchars(zss_t('datasets.create.mount')); ?></span><select id="new-dataset-mount" class="zss-select"><option value="yes"><?php echo htmlspecialchars(zss_t('common.yes')); ?></option><option value="no"><?php echo htmlspecialchars(zss_t('common.no')); ?></option></select></label>
        <label class="zss-field"><span><?php echo htmlspecialchars(zss_t('datasets.create.mountpoint')); ?></span><input id="new-dataset-mountpoint" class="zss-input" type="text" placeholder="<?php echo htmlspecialchars(zss_t('datasets.create.mountpoint_placeholder')); ?>"><small id="new-dataset-default-mountpoint"></small></label>
        <label class="zss-field"><span><?php echo htmlspecialchars(zss_t('datasets.create.atime')); ?></span><select id="new-dataset-atime" class="zss-select"><option value="inherit"><?php echo htmlspecialchars(zss_t('common.inherit')); ?></option><option value="off">Off</option><option value="on">On</option></select></label>
        <label class="zss-field"><span><?php echo htmlspecialchars(zss_t('datasets.create.casesensitivity')); ?></span><select id="new-dataset-casesensitivity" class="zss-select"><option value="inherit"><?php echo htmlspecialchars(zss_t('datasets.create.zfs_default')); ?></option><option value="sensitive">Sensitive</option><option value="insensitive">Insensitive</option><option value="mixed">Mixed</option></select></label>
        <label class="zss-field"><span><?php echo htmlspecialchars(zss_t('datasets.create.compression')); ?></span><select id="new-dataset-compression" class="zss-select"><option value="inherit"><?php echo htmlspecialchars(zss_t('common.inherit')); ?></option><option value="off">Off</option><option value="lz4">lz4</option><option value="gzip">gzip</option><option value="zstd">zstd</option></select></label>
        <label class="zss-field"><span><?php echo htmlspecialchars(zss_t('datasets.create.quota')); ?></span><span class="zss-inline-fields"><input id="new-dataset-quota" class="zss-input" type="number" min="0" placeholder="0"><select id="new-dataset-quota-unit" class="zss-select"><option value="M">MiB</option><option value="G">GiB</option><option value="T">TiB</option></select></span><small><?php echo htmlspecialchars(zss_t('datasets.create.quota_help')); ?></small></label>
    </div>
    <div class="zss-panel-footer"><button class="zss-btn zss-btn-primary" type="button" onclick="createDataset()"><?php echo htmlspecialchars(zss_t('datasets.create.action')); ?></button></div>
</section>

<div id="edit-modal" class="zss-modal" style="display:none;"><div class="zss-modal-card"><div class="zss-modal-header"><h2><?php echo htmlspecialchars(zss_t('datasets.modal.title')); ?></h2><button class="zss-icon-button" onclick="closeModal()">×</button></div><div class="zss-form-grid"><input type="hidden" id="dataset-name"><label class="zss-check"><input type="checkbox" id="config-enabled"> <?php echo htmlspecialchars(zss_t('datasets.fields.enable')); ?></label><label class="zss-field"><span><?php echo htmlspecialchars(zss_t('datasets.fields.frequency')); ?></span><select id="config-frequency" class="zss-select"><option value="5min"><?php echo htmlspecialchars(zss_t('frequency.5min')); ?></option><option value="15min"><?php echo htmlspecialchars(zss_t('frequency.15min')); ?></option><option value="hourly"><?php echo htmlspecialchars(zss_t('frequency.hourly')); ?></option><option value="daily"><?php echo htmlspecialchars(zss_t('frequency.daily')); ?></option><option value="weekly"><?php echo htmlspecialchars(zss_t('frequency.weekly')); ?></option><option value="monthly"><?php echo htmlspecialchars(zss_t('frequency.monthly')); ?></option></select></label><label class="zss-field"><span><?php echo htmlspecialchars(zss_t('datasets.fields.keep')); ?></span><input id="config-keep" class="zss-input" type="number" min="1" value="31"></label><label class="zss-field" id="row-time" style="display:none;"><span><?php echo htmlspecialchars(zss_t('datasets.fields.time')); ?></span><input id="config-time" class="zss-input" type="time" value="00:00"></label><label class="zss-field" id="row-day" style="display:none;"><span id="label-day"><?php echo htmlspecialchars(zss_t('datasets.fields.day')); ?></span><select id="config-day-weekly" class="zss-select" style="display:none;"><option value="1"><?php echo htmlspecialchars(zss_t('weekday.1')); ?></option><option value="2"><?php echo htmlspecialchars(zss_t('weekday.2')); ?></option><option value="3"><?php echo htmlspecialchars(zss_t('weekday.3')); ?></option><option value="4"><?php echo htmlspecialchars(zss_t('weekday.4')); ?></option><option value="5"><?php echo htmlspecialchars(zss_t('weekday.5')); ?></option><option value="6"><?php echo htmlspecialchars(zss_t('weekday.6')); ?></option><option value="7"><?php echo htmlspecialchars(zss_t('weekday.7')); ?></option></select><select id="config-day-monthly" class="zss-select" style="display:none;"></select></label><label class="zss-check"><input type="checkbox" id="config-readonly"> <?php echo htmlspecialchars(zss_t('datasets.fields.readonly')); ?></label><label class="zss-field"><span><?php echo htmlspecialchars(zss_t('datasets.fields.retain_days')); ?></span><input id="config-retain-days" class="zss-input" type="number" min="0" value="0"></label></div><div class="zss-modal-footer"><button class="zss-btn zss-btn-secondary" onclick="closeModal()"><?php echo htmlspecialchars(zss_t('common.cancel')); ?></button><button class="zss-btn zss-btn-primary" onclick="saveConfig()"><?php echo htmlspecialchars(zss_t('common.save')); ?></button></div></div></div>

<?php require __DIR__ . '/layout/footer.php'; ?>
