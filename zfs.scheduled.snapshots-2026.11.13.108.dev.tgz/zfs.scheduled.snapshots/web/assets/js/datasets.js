let currentDatasets = [];

const monthlySelect = () => document.getElementById('config-day-monthly');
for (let i = 1; i <= 31; i++) {
    const option = document.createElement('option');
    option.value = i;
    option.textContent = ZSS_LOCALE === 'zh-CN' ? `${i} 号` : `${i}`;
    monthlySelect().appendChild(option);
}

document.getElementById('config-frequency').addEventListener('change', e => updateFieldVisibility(e.target.value));
document.getElementById('new-dataset-mount').addEventListener('change', e => {
    const mountpoint = document.getElementById('new-dataset-mountpoint');
    mountpoint.disabled = e.target.value === 'no';
    if (mountpoint.disabled) mountpoint.value = '';
    updateDefaultMountpointHint();
});
document.getElementById('new-dataset-parent').addEventListener('change', updateDefaultMountpointHint);
document.getElementById('new-dataset-child').addEventListener('input', updateDefaultMountpointHint);

function updateFieldVisibility(frequency) {
    const timeRow = document.getElementById('row-time');
    const dayRow = document.getElementById('row-day');
    const weeklySelect = document.getElementById('config-day-weekly');
    const monthlySelectEl = document.getElementById('config-day-monthly');
    const dayLabel = document.getElementById('label-day');
    timeRow.style.display = ['daily', 'weekly', 'monthly'].includes(frequency) ? 'grid' : 'none';
    dayRow.style.display = ['weekly', 'monthly'].includes(frequency) ? 'grid' : 'none';
    if (frequency === 'weekly') {
        dayLabel.textContent = t('datasets.fields.weekday', 'Weekday');
        weeklySelect.style.display = 'block';
        monthlySelectEl.style.display = 'none';
    } else if (frequency === 'monthly') {
        dayLabel.textContent = t('datasets.fields.day', 'Day');
        weeklySelect.style.display = 'none';
        monthlySelectEl.style.display = 'block';
    }
}

async function createDataset() {
    const parent = document.getElementById('new-dataset-parent').value;
    const childInput = document.getElementById('new-dataset-child');
    const child = childInput.value.trim().replace(/^\/+|\/+$/g, '');
    if (!parent || !child) {
        zssToast({
            type: 'error',
            title: t('datasets.create.failed', 'Dataset creation failed'),
            message: t('datasets.create.name_required', 'Dataset name is required'),
        });
        return;
    }
    const name = `${parent}/${child}`;
    const confirmed = await zssConfirmAction({
        title: t('datasets.create.title', 'Create dataset'),
        message: t('datasets.create.confirm', 'Create dataset {name}?', { name }),
        detail: name,
        confirmText: t('datasets.create.action', 'Create dataset'),
    });
    if (!confirmed) return;
    const payload = {
        parent,
        child,
        mount: document.getElementById('new-dataset-mount').value,
        mountpoint: document.getElementById('new-dataset-mountpoint').value.trim(),
        atime: document.getElementById('new-dataset-atime').value,
        casesensitivity: document.getElementById('new-dataset-casesensitivity').value,
        compression: document.getElementById('new-dataset-compression').value,
        quota: document.getElementById('new-dataset-quota').value.trim(),
        quota_unit: document.getElementById('new-dataset-quota-unit').value,
    };
    try {
        const result = await postJson('../api/dataset-create.php', payload);
        if (result.ok) {
            childInput.value = '';
            document.getElementById('new-dataset-mountpoint').value = '';
            document.getElementById('new-dataset-quota').value = '';
            updateDefaultMountpointHint();
            invalidateDatasetsCache();
            zssInvalidateDataCache();
            await loadDatasets();
            if (typeof window.refreshResourceTree === 'function') window.refreshResourceTree();
            zssToast({ type: 'success', title: t('datasets.create.success', 'Dataset created') });
        } else {
            zssToast({
                type: 'error',
                title: t('datasets.create.failed', 'Dataset creation failed'),
                message: result.error?.message || t('common.unknown_error', 'Unknown error'),
            });
        }
    } catch (error) {
        zssToast({ type: 'error', title: t('common.request_failed', 'Request failed'), message: error.message });
    }
}

function updateDatasetContext(datasets) {
    const datasetCount = document.getElementById('ctx-dataset-count');
    const enabledCount = document.getElementById('ctx-enabled-count');
    const snapshotCount = document.getElementById('ctx-snapshot-count');
    if (!datasetCount || !enabledCount || !snapshotCount) return;
    datasetCount.textContent = datasets.length;
    enabledCount.textContent = datasets.filter(ds => ds.enabled).length;
    snapshotCount.textContent = datasets.reduce((sum, ds) => sum + (ds.snapshot_count || 0), 0);
    updateDatasetInventoryCount(datasets);
}

function updateDatasetInventoryCount(datasets) {
    const el = document.getElementById('datasets-inventory-count');
    if (!el) return;
    const visible = datasets.length;
    const enabled = datasets.filter(ds => ds.enabled).length;
    const total = datasets.reduce((sum, ds) => sum + (ds.snapshot_count || 0), 0);
    el.textContent = t('datasets.inventory.count', '{visible} visible · {enabled} enabled · {total} snapshots', {
        visible,
        enabled,
        total,
    });
}

async function loadDatasets() {
    // Paint the previous page's payload first so the table never flashes an
    // empty/Loading state, then replace it with the fresh response.
    const epochAtStart = zssCacheEpochValue();
    const cached = zssCacheGet('datasets');
    if (cached && cached.ok) {
        // Cached rows are read-only until the refresh confirms them: opening
        // the edit form from a stale payload could overwrite a schedule that
        // changed elsewhere in the meantime.
        renderDatasetsTable(cached, { stale: true });
    }

    const data = await fetchDatasetsShared();
    // A write may have invalidated the payloads while this request was in
    // flight. Its response can predate the write, so never paint or cache it.
    if (zssCacheEpochValue() !== epochAtStart) {
        return;
    }
    if (!data || !data.ok) {
        if (!(cached && cached.ok)) {
            renderTableMessage('datasets-table', `${t('common.load_failed', 'Load failed')}: ${data?.error?.message || t('common.api_error', 'API error')}`, 10);
        } else {
            zssNotifyStale(data?.error);
            zssMarkStale('datasets');
        }
        return;
    }

    zssMarkFresh('datasets');
    zssCacheSet('datasets', data);
    renderDatasetsTable(data);
}

// Complete payload identity: every field the table, the edit form, and the
// create-parent picker read. A partial key would misjudge "same rows" when a
// schedule changed (frequency, keep, readonly, retain_days) and then unlock
// the edit action while currentDatasets still holds the old schedule.
function datasetsPayloadKey(datasets) {
    return JSON.stringify(datasets);
}

let datasetsRenderState = { key: '', stale: false };

function unlockDatasetEditActions(tbody) {
    tbody.querySelectorAll('button[data-action="edit-dataset"][disabled]').forEach(button => {
        button.disabled = false;
        button.removeAttribute('aria-disabled');
    });
}

function renderDatasetsTable(payload, options = {}) {
    const datasets = (payload && payload.data) || [];
    const tbody = document.getElementById('datasets-table');
    const key = datasetsPayloadKey(datasets);

    // The stale paint disabled every edit action. An identical confirmed
    // payload only needs the lock lifted, not a full table rebuild.
    if (tbody && !options.stale && datasetsRenderState.stale && datasetsRenderState.key === key) {
        currentDatasets = datasets;
        unlockDatasetEditActions(tbody);
        datasetsRenderState.stale = false;
        return;
    }

    currentDatasets = datasets;
    updateDatasetContext(currentDatasets);
    updateCreateParentOptions(currentDatasets);
    tbody.innerHTML = '';
    datasetsRenderState = { key, stale: !!options.stale };
    if (currentDatasets.length === 0) {
        renderTableMessage('datasets-table', t('datasets.empty', 'No datasets'), 10);
        return;
    }
    currentDatasets.forEach(ds => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><a class="zss-dataset-link" href="${withLang(`snapshots.php?dataset=${encodeURIComponent(ds.name)}`)}">${escapeHtml(ds.name)}</a></td>
            <td><span class="zss-badge ${ds.enabled ? 'zss-badge-success' : 'zss-badge-muted'}">${escapeHtml(ds.enabled ? t('common.enabled', 'Enabled') : t('common.disabled', 'Disabled'))}</span></td>
            <td>${escapeHtml(frequencyLabel(ds.frequency))}</td>
            <td>${renderKeepGauge(ds)}</td>
            <td>${renderReadonlyWindow(ds)}</td>
            <td><span class="zss-badge ${ds.readonly ? 'zss-badge-info' : 'zss-badge-muted'}">${escapeHtml(ds.readonly ? t('common.yes', 'Yes') : t('common.no', 'No'))}</span></td>
            <td>${renderHeldBadge(Number(ds.held_snapshot_count) || 0)}</td>
            <td>${escapeHtml(ds.snapshot_count ?? 0)}</td>
            <td>${ds.latest_snapshot_at ? escapeHtml(formatTimestamp(ds.latest_snapshot_at)) : '-'}</td>
            <td><div class="zss-action-row"><button type="button" class="zss-btn zss-btn-secondary zss-btn-small" data-action="edit-dataset" data-name="${escapeHtml(JSON.stringify(ds.name))}"${options.stale ? ' disabled aria-disabled="true"' : ''}>${escapeHtml(t('datasets.actions.edit_schedule', 'Edit scheduled snapshots'))}</button><a class="zss-btn zss-btn-secondary zss-btn-small" href="${withLang(`snapshots.php?dataset=${encodeURIComponent(ds.name)}`)}">${escapeHtml(t('datasets.actions.snapshots', 'Snapshots'))}</a></div></td>
        `;
        tbody.appendChild(row);
    });
}

function renderKeepGauge(ds) {
    const keep = Number(ds.keep);
    const count = Number(ds.snapshot_count) || 0;

    // No retention quota configured (or invalid): fall back to a plain count.
    if (!Number.isFinite(keep) || keep <= 0) {
        return `<span class="zss-keep-count">${escapeHtml(String(count))}</span>`;
    }

    const percent = Math.min(100, Math.round((count / keep) * 100));
    const tier = count > keep ? 'high' : percent >= 80 ? 'mid' : 'ok';
    return `
        <span class="zss-keep-gauge">
            <span class="zss-bar"><span class="zss-bar-fill ${tier}" style="width:${percent}%"></span></span>
            <span class="zss-keep-count" title="${escapeHtml(`${percent}%`)}">${escapeHtml(t('datasets.keep_gauge.of', '{count} / {keep}', { count, keep }))}</span>
        </span>
    `;
}

function renderReadonlyWindow(ds) {
    const days = Number(ds.retain_days);
    return escapeHtml(
        Number.isFinite(days) && days > 0
            ? t('datasets.readonly_window.days', '{days} days', { days })
            : t('datasets.readonly_window.off', 'Off')
    );
}

function renderHeldBadge(heldCount) {
    const label = t('snapshots.context.protected', 'Protected');
    return heldCount > 0
        ? `<span class="zss-held-badge">${escapeHtml(label)} ${escapeHtml(String(heldCount))}</span>`
        : `<span class="zss-held-badge is-zero">${escapeHtml(label)} 0</span>`;
}

function updateCreateParentOptions(datasets) {
    const select = document.getElementById('new-dataset-parent');
    const previous = select.value;
    select.innerHTML = '';
    const rootDatasets = datasets.filter(ds => (!ds.type || ds.type === 'filesystem') && ds.is_root);
    rootDatasets.forEach(ds => {
        const option = document.createElement('option');
        option.value = ds.name;
        option.textContent = ds.name;
        select.appendChild(option);
    });
    if (previous && rootDatasets.some(ds => ds.name === previous)) select.value = previous;
    updateDefaultMountpointHint();
}

function updateDefaultMountpointHint() {
    const hint = document.getElementById('new-dataset-default-mountpoint');
    const mount = document.getElementById('new-dataset-mount').value;
    const parent = document.getElementById('new-dataset-parent').value;
    const child = document.getElementById('new-dataset-child').value.trim().replace(/^\/+|\/+$/g, '');
    if (mount === 'no') { hint.textContent = t('datasets.create.mountpoint_none', 'Mountpoint will be disabled.'); return; }
    if (!parent) { hint.textContent = t('datasets.create.mountpoint_default_empty', 'Leave empty to use the ZFS default mountpoint.'); return; }
    hint.textContent = t('datasets.create.mountpoint_default', 'Leave empty for default: /mnt/{path}', { path: `${parent}${child ? `/${child}` : '/<child>'}` });
}

function openEdit(name) {
    const ds = currentDatasets.find(d => d.name === name);
    if (!ds) return;
    document.getElementById('dataset-name').value = ds.name;
    document.getElementById('config-enabled').checked = !!ds.enabled;
    document.getElementById('config-frequency').value = ds.frequency;
    document.getElementById('config-keep').value = ds.keep;
    document.getElementById('config-time').value = ds.time || '00:00';
    document.getElementById('config-day-weekly').value = ds.day || 1;
    document.getElementById('config-day-monthly').value = ds.day || 1;
    document.getElementById('config-readonly').checked = !!ds.readonly;
    document.getElementById('config-retain-days').value = ds.retain_days;
    updateFieldVisibility(ds.frequency);
    document.getElementById('edit-modal').style.display = 'flex';
}
function closeModal() { document.getElementById('edit-modal').style.display = 'none'; }
window.addEventListener('click', event => { if (event.target === document.getElementById('edit-modal')) closeModal(); });

async function saveConfig() {
    const name = document.getElementById('dataset-name').value;
    const frequency = document.getElementById('config-frequency').value;
    const day = frequency === 'weekly' ? parseInt(document.getElementById('config-day-weekly').value) : frequency === 'monthly' ? parseInt(document.getElementById('config-day-monthly').value) : 1;
    const payload = {
        enabled: document.getElementById('config-enabled').checked,
        frequency,
        keep: parseInt(document.getElementById('config-keep').value),
        time: document.getElementById('config-time').value,
        day,
        readonly: document.getElementById('config-readonly').checked,
        retain_days: parseInt(document.getElementById('config-retain-days').value),
    };
    try {
        const result = await postJson('../api/dataset-update.php', { name, ...payload });
        if (result.ok) {
            closeModal();
            invalidateDatasetsCache();
            zssInvalidateDataCache();
            await loadDatasets();
            if (typeof window.refreshResourceTree === 'function') window.refreshResourceTree();
            zssToast({ type: 'success', title: t('datasets.save_success', 'Saved successfully') });
        } else {
            zssToast({
                type: 'error',
                title: t('datasets.save_failed', 'Save failed'),
                message: result.error?.message || t('common.unknown_error', 'Unknown error'),
            });
        }
    } catch (error) {
        zssToast({ type: 'error', title: t('common.request_failed', 'Request failed'), message: error.message });
    }
}

document.addEventListener('DOMContentLoaded', loadDatasets);

// Delegated handler for the edit button in each dataset row; mirrors the
// snapshots timeline pattern (JSON-encoded names in data attributes, see
// renderSnapshotActions) instead of inline JSON onclick handlers.
document.getElementById('datasets-table').addEventListener('click', function(event) {
    const button = event.target.closest('button[data-action="edit-dataset"][data-name]');
    if (!button) {
        return;
    }

    let name = '';
    try {
        name = JSON.parse(button.dataset.name || '""');
    } catch (error) {
        name = '';
    }

    if (!name) {
        zssToast({
            type: 'error',
            title: t('common.request_failed', 'Request failed'),
            message: t('datasets.invalid_action_name', 'Invalid dataset name'),
        });
        return;
    }

    openEdit(name);
});
